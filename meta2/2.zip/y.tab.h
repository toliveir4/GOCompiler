/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    SEMICOLON = 258,
    COMMA = 259,
    ASSIGN = 260,
    STAR = 261,
    DIV = 262,
    MINUS = 263,
    PLUS = 264,
    EQ = 265,
    GE = 266,
    GT = 267,
    LE = 268,
    LT = 269,
    MOD = 270,
    NE = 271,
    NOT = 272,
    AND = 273,
    OR = 274,
    LBRACE = 275,
    LPAR = 276,
    LSQ = 277,
    RBRACE = 278,
    RPAR = 279,
    RSQ = 280,
    PACKAGE = 281,
    RETURN = 282,
    ELSE = 283,
    FOR = 284,
    IF = 285,
    VAR = 286,
    INT = 287,
    FLOAT32 = 288,
    BOOL = 289,
    STRING = 290,
    PRINT = 291,
    PARSEINT = 292,
    FUNC = 293,
    CMDARGS = 294,
    BLANKID = 295,
    RESERVED = 296,
    REALLIT = 297,
    INTLIT = 298,
    STRLIT = 299,
    ID = 300
  };
#endif
/* Tokens.  */
#define SEMICOLON 258
#define COMMA 259
#define ASSIGN 260
#define STAR 261
#define DIV 262
#define MINUS 263
#define PLUS 264
#define EQ 265
#define GE 266
#define GT 267
#define LE 268
#define LT 269
#define MOD 270
#define NE 271
#define NOT 272
#define AND 273
#define OR 274
#define LBRACE 275
#define LPAR 276
#define LSQ 277
#define RBRACE 278
#define RPAR 279
#define RSQ 280
#define PACKAGE 281
#define RETURN 282
#define ELSE 283
#define FOR 284
#define IF 285
#define VAR 286
#define INT 287
#define FLOAT32 288
#define BOOL 289
#define STRING 290
#define PRINT 291
#define PARSEINT 292
#define FUNC 293
#define CMDARGS 294
#define BLANKID 295
#define RESERVED 296
#define REALLIT 297
#define INTLIT 298
#define STRLIT 299
#define ID 300

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 21 "gocompiler.y"

    char *valor;
    no_ast *no;

#line 152 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
